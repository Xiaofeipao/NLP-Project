"""Evaluate fixed-G rollouts with identical retry budgets and alternate verifier feedback."""
import argparse
from collections import Counter
from dataclasses import dataclass, field
import gc
import json
from pathlib import Path

from ppnl.core import Grid, OfficialOracle, execute, parse_verdict
from ppnl.data import read_jsonl, write_json, write_jsonl
from ppnl.evaluation import plan_metrics
from ppnl.experiment_freeze import file_hash
from ppnl.modeling import require_cuda
from ppnl.policy import NAMES, greedy_plans
from state_baselines.run import CONFIG
from . import g_probes, last_move
from .audit import require
from .path_validation import fixed_development, load_runner, score_paths
from .direction_controls import distance
from .schema import State
from .single import LABELS
from .train_gpu import split


class SharedPolicy:
    """Cache the same four G scores for each state across all methods."""

    def __init__(self, policy):
        self.policy = policy
        self.cache = {}

    def scores(self, observations):
        keys = [State.from_grid(g, pos) for g, pos in observations]
        missing = {k: obs for k, obs in zip(keys, observations, strict=True) if k not in self.cache}
        if missing:
            self.cache.update(zip(missing, self.policy.scores(list(missing.values())), strict=True))
        return [self.cache[k] for k in keys]


@dataclass
class Rollout:
    grid: Grid
    position: tuple
    actions: list = field(default_factory=list)
    excluded: set = field(default_factory=set)
    events: list = field(default_factory=list)
    retries: int = 0
    stop: str = ""

    @property
    def plan(self):
        return " ".join(self.actions)


def generate(runs, scorer, max_steps, max_retries=0, verify_moves=None, *, stop_only=False):
    """Regenerate from the current prefix, excluding rejected directions at that step."""
    active = [r for r in runs if not r.stop]
    while active:
        candidates, pending = [], []
        for r in active:
            if len(r.actions) >= max_steps:
                r.stop = "step_limit"
            elif verify_moves is None and r.position == r.grid.goal:
                r.stop = "coordinate_goal"
            else:
                options = [a for a in NAMES if a not in r.excluded]
                if not options:
                    r.stop = "directions_exhausted"
                else:
                    candidates.append(options)
                    pending.append(r)
        if not pending:
            break
        scores = scorer.scores([(r.grid, r.position) for r in pending])
        moves = [max(options, key=lambda a: score[NAMES.index(a)])
                 for options, score in zip(candidates, scores, strict=True)]
        observations = [(State.from_grid(r.grid, r.position), a) for r, a in zip(pending, moves, strict=True)]
        truth = [last_move.transition(s, a) for s, a in observations]
        feedback = verify_moves(observations) if verify_moves is not None else [t for _, t in truth]
        active = []
        for r, (state, a), (destination, target), label in zip(pending, observations, truth, feedback, strict=True):
            r.events.append({"from": r.position, "distance_to_goal": distance(state), "action": a,
                             "label": label, "actual": target})
            if verify_moves is None or stop_only:
                r.actions.append(a)
                if stop_only and label == "valid":
                    r.stop = "verified_valid"
                elif destination is None:
                    r.stop = "illegal_move"
                else:
                    r.position = destination
                    r.excluded.clear()
                    active.append(r)
            elif label in ("valid", "goal_not_reached"):
                r.actions.append(a)
                if label == "valid":
                    r.stop = "verified_valid"
                elif destination is None:
                    r.stop = "unexecutable_accepted_move"
                else:
                    r.position = destination
                    r.excluded.clear()
                    active.append(r)
            elif label not in LABELS:
                r.stop = "malformed_verdict"
            elif r.retries == max_retries:
                r.stop = "retry_limit"
            else:
                r.retries += 1
                r.excluded.add(a)
                active.append(r)
    return [{"plan": r.plan, "stop": r.stop, "retries": r.retries, "events": r.events} for r in runs]


def online(grids, scorer, verify_moves, max_steps, retry_budget, *, stop_only=False):
    runs = [Rollout(g, g.start, stop="empty_goal" if g.start == g.goal else "") for g in grids]
    return generate(runs, scorer, max_steps, retry_budget, verify_moves, stop_only=stop_only)


def repair_paths(grids, initial, scorer, verify_paths, max_steps, retry_budget):
    """Recheck each revised path and retain the prefix preceding its reported first error."""
    plans = initial[:]
    status = [""] * len(grids)
    retries = [0] * len(grids)
    logs = [[] for _ in grids]
    excluded = [{} for _ in grids]
    pending = list(range(len(grids)))
    while pending:
        predictions = verify_paths([grids[i] for i in pending], [plans[i] for i in pending])
        continuations, indices = [], []
        for i, feedback in zip(pending, predictions, strict=True):
            g, tokens = grids[i], plans[i].split()
            logs[i].append({"plan": plans[i], "verdict": feedback})
            verdict = parse_verdict(feedback)
            if verdict is None:
                status[i] = "malformed_verdict"
                continue
            valid, step, reason = verdict
            if valid or retries[i] == retry_budget:
                status[i] = "verified_valid" if valid else "retry_limit"
                continue
            if (reason == "goal_not_reached" and step != len(tokens) + 1
                    or reason != "goal_not_reached" and step > len(tokens)):
                status[i] = "invalid_error_index"
                continue
            prefix = tokens[:step - 1]
            traced = execute(g, " ".join(prefix))
            if not traced.feasible:
                status[i] = "unexecutable_prefix"
                continue
            if len(prefix) >= max_steps:
                status[i] = "step_limit"
                continue
            bans = excluded[i].setdefault(tuple(prefix), set())
            if step <= len(tokens):
                bans.add(tokens[step - 1])
            if len(bans) == len(NAMES):
                status[i] = "directions_exhausted"
                continue
            position = g.start if not prefix else traced.trace[len(prefix) - 1]["to"]
            continuations.append(Rollout(g, position, prefix, set(bans)))
            indices.append(i)
            retries[i] += 1
        if not indices:
            break
        for i, result in zip(indices, generate(continuations, scorer, max_steps), strict=True):
            plans[i] = result["plan"]
        pending = indices
    return [{"plan": p, "stop": s, "retries": c, "checks": log}
            for p, s, c, log in zip(plans, status, retries, logs, strict=True)]


def grade(grids, direct_valid, run, oracle):
    plans = [r["plan"] for r in run]
    verdicts = [oracle.check(g, p) for g, p in zip(grids, plans, strict=True)]
    all_events = [e for r in run for e in r.get("events", [])]
    success = [v.valid for v in verdicts]
    stats = plan_metrics(grids, plans)
    stats.update(
        failures=Counter(v.reason for v in verdicts if not v.valid),
        stop_reasons=Counter(r["stop"] for r in run),
        accepted_valid=sum(r["stop"] == "verified_valid" and v.valid for r, v in zip(run, verdicts, strict=True)),
        accepted_invalid=sum(r["stop"] == "verified_valid" and not v.valid for r, v in zip(run, verdicts, strict=True)),
        arriving_move_labeled_unfinished=sum(any(e["actual"] == "valid" and e["label"] == "goal_not_reached"
                                     for e in r.get("events", [])) for r in run),
        arriving_move_labeled_action_error=sum(any(e["actual"] == "valid" and e["label"] not in ("valid", "goal_not_reached")
                                 for e in r.get("events", [])) for r in run),
        false_valid_step=sum(e["label"] == "valid" and e["actual"] != "valid" for e in all_events),
        false_valid_step_by_distance=Counter("adjacent" if e["distance_to_goal"] == 1 else "nonadjacent"
                                             for e in all_events
                                             if e["label"] == "valid" and e["actual"] != "valid"),
        retries=sum(r["retries"] for r in run),
        recovered_direct_failures=sum(not d and s for d, s in zip(direct_valid, success, strict=True)),
        lost_direct_successes=sum(d and not s for d, s in zip(direct_valid, success, strict=True)),
        direct_failure_total=sum(not d for d in direct_valid),
    )
    return stats, [dict(r, final_verdict=v.label()) for r, v in zip(run, verdicts, strict=True)]


def environment_sets(data, dev_only=False):
    states = {r["id"]: State.from_record(r) for r in read_jsonl(data / "states.jsonl")}
    dev = [(r["id"], states[r["state_id"]].grid()) for r in split(data, "dev") if r["mode"] == "g_next"]
    result = {"dev_G": dev}
    if not dev_only:
        tests = [[(r["id"], Grid.from_dict(r["grid"]), r["candidate"])
                  for r in split(data, s) if r["valid"]] for s in ("test_id", "test_ood")]
        require({(g, p) for _, g, p in tests[0]} == {(g, p) for _, g, p in tests[1]},
                "Fixed tests no longer share one positive path population")
        heldout = {g: row_id for row_id, g, _ in tests[0]}
        result["shared_ID_OOD"] = [(i, g) for g, i in heldout.items()]
    for partition in result.values():
        require(len({g for _, g in partition}) == len(partition) and all(g.start != g.goal for _, g in partition),
                "Expected unique, nontrivial rollout environments")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("data", "executor", "path-results", "generator", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--compare", nargs="+", default=("old_text", "targeted_text"), metavar="RUN")
    parser.add_argument("--retries", type=int, default=2)
    parser.add_argument("--dev-only", action="store_true", help="Evaluate only development rollouts")
    parser.add_argument("--selected-only", action="store_true", help="Skip the supplementary epoch-3 comparison")
    parser.add_argument("--goal-check", action="store_true",
                        help="Allow the first-token valid label only for a move that lands on the goal")
    parser.add_argument("--source-dev", type=Path, help="Also score the frozen, balanced development paths")
    args = parser.parse_args()
    if args.retries < 0:
        parser.error("retries must be nonnegative")
    if not args.compare or len(set(args.compare)) != len(args.compare):
        parser.error("Choose distinct runs for comparison")
    args.out.mkdir(parents=True, exist_ok=False)
    root = args.out
    oracle = OfficialOracle(args.executor)
    manifest = json.loads((args.data / "manifest.json").read_bytes())
    require(oracle.sha256 == manifest["executor_sha256"], "Unexpected executor")
    require(file_hash(args.data / "states.jsonl") == manifest["sha256"]["states.jsonl"], "Unexpected states")
    paths = json.loads(args.path_results.read_bytes())
    names = args.compare
    selected = {k: paths["runs"][k]["selected"] for k in names}
    methods = dict(selected)
    epoch3_methods = {}
    for key in names:
        choice = selected[key]
        if choice["epoch"] == 3:
            epoch3_methods[key] = key
        elif not args.selected_only:
            name = key + "_epoch3"
            epoch3_methods[key] = name
            methods[name] = next(r for r in paths["runs"][key]["history"] if r["epoch"] == 3)
    if args.goal_check and not all(choice.get("first_token") for choice in methods.values()):
        parser.error("--goal-check requires checkpoints with five first-token verdict scores")
    fixed_dev = fixed_development(args.source_dev, oracle) if args.source_dev else None
    torch = require_cuda()
    torch.set_num_threads(2)
    precision = "bfloat16" if torch.cuda.is_bf16_supported() else "float32"
    grunner = load_runner(args.generator, False, precision)
    scorer = SharedPolicy(g_probes.generation_policy(grunner))
    max_steps = CONFIG["max_steps"]
    envs = environment_sets(args.data, dev_only=args.dev_only)
    report = {"fixed_G_checkpoint": str(args.generator), "max_steps": max_steps,
              "retry_budget": args.retries, "selected_V": selected, "same_epoch3_methods": epoch3_methods,
              "verifiers": {name: item["checkpoint"] for name, item in methods.items()},
              "splits": {}, "fixed_test_paths": {}}
    if args.goal_check:
        report["goal_check"] = "mask_valid_unless_candidate_lands_on_goal"
    if fixed_dev:
        report["fixed_dev_paths"] = {}
        report["dev_paths_source_sha256"] = file_hash(args.source_dev)
    fixed = {}

    def save(split_name, method, records):
        ids, grids, _, direct_valid = fixed[split_name]
        stats, scored = grade(grids, direct_valid, records, oracle)
        report["splits"][split_name][method] = stats
        write_jsonl(root / f"{split_name}_{method}.jsonl",
                    [dict(id=i, **r) for i, r in zip(ids, scored, strict=True)])
        write_json(root / "rollouts.json", report)

    oracle_moves = lambda moves: [last_move.transition(s, a)[1] for s, a in moves]
    oracle_paths = lambda gs, ps: [oracle.check(g, p).label() for g, p in zip(gs, ps, strict=True)]
    for split_name, cases in envs.items():
        ids, grids = map(list, zip(*cases))
        baseline = online(grids, scorer, None, max_steps, 0)
        direct = [r["plan"] for r in baseline]
        require(direct == greedy_plans(grids, scorer, masked=False, max_steps=max_steps), "Changed direct protocol")
        fixed[split_name] = (ids, grids, direct, [oracle.check(g, p).valid for g, p in zip(grids, direct, strict=True)])
        report["splits"][split_name] = {}
        save(split_name, "direct", baseline)
        save(split_name, "online_executor_retry", online(grids, scorer, oracle_moves, max_steps, args.retries))
        save(split_name, "whole_executor_retry", repair_paths(grids, direct, scorer, oracle_paths, max_steps, args.retries))
    for name, choice in methods.items():
        runner = load_runner(choice["checkpoint"], choice["verifier_head"], precision,
                             first_token=choice.get("first_token", False), restricted_readout=choice.get("restricted_readout", False))
        if fixed_dev:
            report["fixed_dev_paths"][name] = score_paths(
                runner, *fixed_dev, root / f"dev_{name}_verification.jsonl", goal_check=args.goal_check)
        tests = {}
        for split_name in (() if args.dev_only else ("test_id", "test_ood")):
            rows = split(args.data, split_name)
            gs = [Grid.from_dict(r["grid"]) for r in rows]
            ps = [r["candidate"] for r in rows]
            require(all(oracle.check(g, p).label() == r["label"] for g, p, r in zip(gs, ps, rows, strict=True)),
                    "Changed fixed test labels")
            tests[split_name] = score_paths(runner, rows, gs, ps, root / f"{split_name}_{name}_verification.jsonl",
                                           goal_check=args.goal_check)
        report["fixed_test_paths"][name] = tests
        for split_name, (_, grids, direct, _) in fixed.items():
            def moves(obs):
                return g_probes.verify_moves(runner, obs, goal_check=args.goal_check)

            def candidates(gs, ps):
                return g_probes.verify_plans(runner, gs, ps, goal_check=args.goal_check)

            save(split_name, name + "_online_stop_only", online(grids, scorer, moves, max_steps, 0, stop_only=True))
            save(split_name, name + "_online_retry", online(grids, scorer, moves, max_steps, args.retries))
            save(split_name, name + "_whole_retry", repair_paths(grids, direct, scorer, candidates, max_steps, args.retries))
        del runner
        gc.collect()
        torch.cuda.empty_cache()
        print(f"Completed {'development' if args.dev_only else 'both splits'} for {name}", flush=True)


if __name__ == "__main__":
    main()
