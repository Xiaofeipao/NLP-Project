"""Keep different V actions from each shared state in one optimizer update."""
from collections import Counter, defaultdict
import random

from .single import LABELS


def grouped_order(rows, batch_size, seed, *, generation=2000, verification_per_class=400):
    by_state = defaultdict(list)
    g_indices = []
    for index, row in enumerate(rows):
        if row["mode"] == "v_step":
            by_state[row["state_id"]].append(index)
        else:
            g_indices.append(index)
    labels = Counter(rows[i]["target"] for group in by_state.values() for i in group)
    if len(g_indices) != generation or labels != dict.fromkeys(LABELS, verification_per_class):
        raise ValueError("Rows disagree with the frozen G/V allocation")

    rng = random.Random(seed)
    if batch_size % 2:
        raise ValueError("Grouped batches require an even effective batch size")
    v_batch = batch_size // 2
    groups = []
    singletons = []
    for group in by_state.values():
        if len({rows[i]["candidate"] for i in group}) != len(group):
            raise ValueError("Duplicate action in a V state")
        if len(group) > 1:
            groups.append(group)
        else:
            singletons.extend(group)
    rng.shuffle(groups)
    rng.shuffle(singletons)
    if generation != sum(labels.values()):
        # Fill each update with complete V states; use G examples for the remaining slots.
        sizes = [min(batch_size, len(rows) - i) for i in range(0, len(rows), batch_size)]
        windows = [[] for size in sizes]
        for group in sorted(groups + [[i] for i in singletons], key=len, reverse=True):
            available = [i for i, w in enumerate(windows) if len(w) + len(group) <= sizes[i]]
            if not available:
                raise ValueError("The effective batch cannot hold the complete V groups")
            slot = min(available, key=lambda i: len(windows[i]) / sizes[i])
            windows[slot].extend(group)
        v_counts = list(map(len, windows))
        rng.shuffle(g_indices)
        for window, size in zip(windows, sizes, strict=True):
            window.extend(g_indices.pop() for _ in range(size - len(window)))
            rng.shuffle(window)
        order = [i for window in windows for i in window]
        if sorted(order) != list(range(len(rows))):
            raise RuntimeError("Grouped sampling must visit every example exactly once")
        return order, {"v_labels": dict(labels), "v_examples_per_update_range": [min(v_counts), max(v_counts)],
                       "multi_action_states": len(groups), "grouped_v_examples": sum(map(len, groups))}
    windows = []
    window = []
    for group in groups:
        if len(group) > v_batch:
            raise ValueError("A V group exceeds the V quota in one update")
        if len(window) + len(group) > v_batch:
            while len(window) < v_batch:
                if not singletons:
                    raise ValueError("Too few ungrouped examples to pack full updates")
                window.append(singletons.pop())
            windows.append(window)
            window = []
        window.extend(group)
    remainder = window + singletons
    windows.extend(remainder[i:i + v_batch] for i in range(0, len(remainder), v_batch))
    # Keep the partial update last so no V group crosses an accumulation boundary.
    full, tail = divmod(len(rows), batch_size)
    complete = windows[:full]
    rng.shuffle(complete)
    windows = complete + (windows[full:] if tail else [])
    rng.shuffle(g_indices)
    start = 0
    for window in windows:
        end = start + len(window)
        window.extend(g_indices[start:end])
        rng.shuffle(window)
        start = end
    order = [i for window in windows for i in window]
    if sorted(order) != list(range(len(rows))):
        raise RuntimeError("Grouped sampling must visit every example exactly once")
    return order, {"v_labels": dict(labels), "v_examples_per_full_update": v_batch, "multi_action_states": len(groups),
                   "grouped_v_examples": sum(map(len, groups))}
