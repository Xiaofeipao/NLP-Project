"""Build matched arrival and inward-but-unfinished direction controls."""
import argparse
from collections import Counter, defaultdict
import json
import random
from pathlib import Path
from shutil import copyfile
from tempfile import TemporaryDirectory

from ppnl.core import ACTIONS, OfficialOracle
from ppnl.data import read_jsonl
from ppnl.experiment_freeze import file_hash
from . import g_probes, last_move
from .audit import require
from .audit_paired_actions import coverage, leakage_report, verify_replacements
from .balance_steps import audit_split, token_check
from .build import SOURCE_SHA, write_lines, write_object
from .model_io import read_split
from .paired_actions import ARRIVED, UNFINISHED, control_groups, make_rows, row_key
from .schema import State
from .shortcut_audit import inspect_dataset


PARENT = "142bf234eb6fd4331796e29bd83d1c92ba165114be062e7f0238bdf70c4a1bdd"
ADJACENT_MIN = 220
INWARD_MIN = 90
INWARD_PAIRS_MIN = 40


def distance(state, position=None):
    return sum(abs(a - b) for a, b in zip(state.current if position is None else position, state.goal))


def inward(state, action, target, *, strict=True):
    r, c = state.current
    if target != UNFINISHED or action not in ACTIONS or distance(state) not in (2, 3):
        return False
    if strict and not (0 < r < state.rows - 1 and 0 < c < state.cols - 1):
        return False
    dr, dc = ACTIONS[action]
    return distance(state, (r + dr, c + dc)) == distance(state) - 1


def probe_pool(parent, states, train, oracle):
    allowed_layouts = {states[r["state_id"]].record()["layout_id"] for r in train}
    candidates = {}
    for name in ("g_train_four", "v_train_four"):
        for row in read_jsonl(parent / "diagnostics" / (name + ".jsonl")):
            sid, action = row_key(row)
            state = states[sid]
            require(state.record()["layout_id"] in allowed_layouts, "Nontraining probe layout")
            require(action in ACTIONS and row["target"] == g_probes.reference(state, action, oracle)
                    and row["input"] == g_probes.step_input(state, action), row["id"])
            old = candidates.setdefault((sid, action), row["target"])
            require(old == row["target"], "Conflicting probe annotations")
    return candidates


def select(train, states, pool, groups):
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import coo_matrix

    rows = {row_key(r): r for r in train if r["mode"] == "v_step"}
    fixed = {k for k, r in rows.items() if r["target"] != UNFINISHED}
    known_states = {r["state_id"] for r in train}
    targets = {s for s, a in fixed if rows[s, a]["target"] == ARRIVED}
    old_b = rows.keys() - fixed
    keys = sorted(old_b | {k for k, t in pool.items() if t == UNFINISHED and k[0] in known_states
                           and (k[0] in targets or inward(states[k[0]], k[1], t))})
    xi = {k: i for i, k in enumerate(keys)}
    variables = len(keys)
    lower, upper = [0.] * variables, [1.] * variables
    rng = random.Random(42)
    costs = [float(k not in old_b) + 0.000001 * rng.random() for k in keys]
    terms, ri, ci, lo, hi = [], [], [], [], []

    def add(indices, minimum=0, maximum=np.inf, weights=None):
        indices = list(indices)
        ri.extend([len(lo)] * len(indices))
        ci.extend(indices)
        terms.extend([1] * len(indices) if weights is None else weights)
        lo.append(minimum)
        hi.append(maximum)

    def indicator(cost=0.):
        i = len(costs)
        costs.append(cost)
        lower.append(0.)
        upper.append(1.)
        return i

    old_ids = {r["id"]: k for k, r in rows.items()}
    layout = {s: states[s].record()["layout_id"] for s in known_states}
    fixed_layouts = {layout[r["state_id"]] for r in train if r["mode"] == "g_next"} | {layout[s] for s, _ in fixed}
    by_state, by_direction, by_layout = defaultdict(list), defaultdict(list), defaultdict(list)
    inward_by_state, inward_by_direction, inward_by_distance = defaultdict(list), defaultdict(list), defaultdict(list)
    neighbor_layouts = defaultdict(list)
    untouched = []
    present_states = {s for s, _ in old_b}
    for (s, a), i in xi.items():
        by_state[s].append(i)
        by_direction[a].append(i)
        by_layout[layout[s]].append(i)
        if inward(states[s], a, UNFINISHED):
            inward_by_state[s].append(i)
            inward_by_direction[a].append(i)
            inward_by_distance[distance(states[s])].append(i)
            neighbor_layouts[layout[s]].append(i)
        elif s not in targets:
            untouched.append(i)
        if states[s].current == states[s].goal:
            lower[i] = 1.
    for a in ACTIONS:
        n = sum(k[1] == a for k in old_b)
        add(by_direction[a], n, n)
        add(inward_by_direction[a], 18)
    for m in inward_by_distance.values():
        add(m, 35)
    for m in neighbor_layouts.values():
        add(m, maximum=3)
    add((i for m in inward_by_state.values() for i in m), INWARD_MIN)
    add(untouched, 25)
    for lid in layout.values():
        if lid not in fixed_layouts:
            # Each layout present in the frozen training partition remains represented.
            fixed_layouts.add(lid)
            add(by_layout[lid], 1)

    adjacent_indicators = []
    for s in sorted(targets):
        if not by_state[s]:
            continue
        if s in present_states:
            add(by_state[s], 1)
        j = indicator()
        add([*by_state[s], j], weights=[1] * len(by_state[s]) + [-1])
        adjacent_indicators.append(j)
    add(adjacent_indicators, ADJACENT_MIN)

    fixed_states = {s for s, a in fixed if a in ACTIONS}
    direction_pairs = []
    for s, mine in sorted(inward_by_state.items()):
        compare = sorted(set(by_state[s]) - set(mine))
        if not compare and s not in fixed_states:
            continue
        j = indicator()
        add([*mine, j], weights=[1] * len(mine) + [-1])
        if s not in fixed_states:
            add([*compare, j], weights=[1] * len(compare) + [-1])
        direction_pairs.append(j)
    add(direction_pairs, INWARD_PAIRS_MIN)

    for group in groups:
        members = [old_ids[i] for i in group["rows"]]
        movable = [xi[k] for k in members if k in xi]
        if group["kind"].startswith("four_"):
            labels = {rows[k]["target"] for k in members}
            if len(labels) == 4:
                add(movable, len(movable))
            elif movable:
                j = indicator(cost=-0.04)
                for i in movable:
                    add([i, j], weights=[1, -1])
        elif group["kind"] != "same_state_arrival":
            add(movable, len(movable))
    matrix = coo_matrix((terms, (ri, ci)), shape=(len(lo), len(costs))).tocsc()
    result = milp(costs, integrality=np.ones(len(costs)), bounds=Bounds(lower, upper),
                  constraints=LinearConstraint(matrix, lo, hi), options={"mip_rel_gap": 0.0001})
    require(result.success, result.message)
    chosen = np.rint(result.x)
    values = matrix @ chosen
    require(all(values >= lo) and all(values <= hi) and all(chosen >= lower) and all(chosen <= upper),
            "Rounded constraints failed")
    return fixed | {k for k, i in xi.items() if chosen[i]}


def direction_groups(rows, states):
    by_state = defaultdict(list)
    for r in rows:
        if r["mode"] == "v_step" and r["candidate"] in ACTIONS:
            by_state[r["state_id"]].append(r)
    result = {"adjacent": [], "inward": []}
    for sid, moves in sorted(by_state.items()):
        s = states[sid]
        arrive = [r for r in moves if r["target"] == ARRIVED]
        unfinished = [r for r in moves if r["target"] == UNFINISHED]
        if distance(s) == 1 and arrive and unfinished:
            result["adjacent"].append({"state_id": sid, "arrive": arrive[0]["id"],
                                       "other_legal": sorted(r["id"] for r in unfinished)})
        closer = {r["id"] for r in moves if inward(s, r["candidate"], r["target"])}
        if closer:
            comparison = sorted(r["id"] for r in moves if r["id"] not in closer)
            if comparison:
                result["inward"].append({"state_id": sid, "toward_but_unfinished": sorted(closer),
                                         "other_direction": comparison, "distance_before": distance(s)})
    return result


def profile(rows, states):
    selected = {row_key(r): r["target"] for r in rows if r["mode"] == "v_step"}
    closer = [k for k, t in selected.items() if inward(states[k[0]], k[1], t)]
    return {"adjacent_pairs": len(direction_groups(rows, states)["adjacent"]),
            "inward_pairs": len(direction_groups(rows, states)["inward"]),
            "strict_inward_actions": len(closer), "strict_inward_by_direction": Counter(a for _, a in closer),
            "strict_inward_by_distance": Counter(distance(states[s]) for s, _ in closer),
            "strict_inward_layouts": len({states[s].record()["layout_id"] for s, _ in closer}),
            "inward_actions_all_positions": sum(inward(states[s], a, t, strict=False)
                                                for (s, a), t in selected.items())}


def build(args):
    parent, output = args.parent, args.out
    require(not output.exists(), "Use a new output directory")
    require(file_hash(parent / "manifest.json") == PARENT, "Unexpected paired parent")
    manifest = json.loads((parent / "manifest.json").read_bytes())
    require(all(file_hash(parent / p) == h for p, h in manifest["sha256"].items()), "Changed parent file")
    require(all(file_hash(args.source / p) == h for p, h in SOURCE_SHA.items()), "Changed source partition")
    oracle = OfficialOracle(args.executor)
    require(oracle.sha256 == manifest["executor_sha256"]
            and file_hash(args.tokenizer) == manifest["tokenizer_sha256"], "Frozen executor/tokenizer mismatch")
    states = {r["id"]: State.from_record(r) for r in read_jsonl(parent / "states.jsonl")}
    old = read_split(parent, "train", version=g_probes.VERSION, fingerprint=g_probes.template_hash())
    controls = json.loads((parent / "control_groups.json").read_bytes())
    pool = probe_pool(parent, states, old, oracle)
    picked = select(old, states, pool, controls["train"])
    new = make_rows(old, picked, states, new_id_prefix="train-direction-V")
    anchor_updates = verify_replacements(old, new)
    old_v = [r for r in old if r["mode"] == "v_step"]
    before, after = profile(old, states), profile(new, states)
    require(after["adjacent_pairs"] >= ADJACENT_MIN and after["strict_inward_actions"] >= INWARD_MIN
            and after["inward_pairs"] >= INWARD_PAIRS_MIN, "Missing targeted contrasts")
    new_groups = control_groups(new, [g for g in controls["train"] if g["kind"] != "same_state_arrival"], states)
    old_v_by_id = {r["id"]: r for p in (args.balanced / "train.jsonl", parent / "train.jsonl")
                   for r in read_jsonl(p) if r["mode"] == "v_step"}
    prev = read_split(args.previous, "train", version=last_move.VERSION, fingerprint=last_move.template_hash())
    kept_train_states = {r["state_id"]: states[r["state_id"]] for r in new}
    train_audit = audit_split(new, new_groups, kept_train_states, prev, read_jsonl(args.source / "train.jsonl"),
                              oracle, "train", parent_verification=old_v_by_id)
    output.parent.mkdir(exist_ok=True, parents=True)
    with TemporaryDirectory(dir=output.parent) as tmp:
        stage = Path(tmp) / "dataset"
        stage.mkdir()
        train_views = {f"diagnostics/{name}.jsonl" for name in ("g_train_four", "g_train_balanced", "v_train_four")}
        changed = {"train.jsonl", "control_groups.json", "audit.json", "shortcut_audit.json",
                   "diagnostics/previous_train_controls.json"} | train_views
        for name in manifest["sha256"].keys() - changed:
            target = stage / name
            target.parent.mkdir(exist_ok=True, parents=True)
            copyfile(parent / name, target)
        write_lines(stage / "train.jsonl", new)
        write_object(stage / "control_groups.json", {"train": new_groups, "dev": controls["dev"]})
        write_object(stage / "direction_groups.json", direction_groups(new, states))
        for name in sorted(train_views):
            view = read_jsonl(parent / name)
            for r in view:
                r["in_same_split_supervised_V"] = row_key(r) in picked
            write_lines(stage / name, view)
        old_control_path = "diagnostics/previous_train_controls.json"
        old_control = json.loads((parent / old_control_path).read_bytes())
        by_id = {r["id"]: row_key(r) for r in read_jsonl(stage / "diagnostics/v_train_four.jsonl")}
        for g in old_control:
            g["supervised_members"] = sum(by_id[i] in picked for i in g["probe_ids"])
        write_object(stage / old_control_path, old_control)
        report = json.loads((parent / "audit.json").read_bytes())
        train_audit["previous_shortest_arrival_axes"] = report["supervised"]["train"]["previous_shortest_arrival_axes"]
        report["supervised"]["train"] = train_audit
        # Carry historical reports as provenance and keep current diagnostic counts explicit.
        report["direction_controls"] = {
            "before": before, "after": after, "G_anchor_metadata_updates": anchor_updates,
            "before_coverage": coverage(old, states, old_v), "after_coverage": coverage(new, states, old_v),
            "unique_compass_probe_cases": len(pool),
            "strict_inward_pool": sum(inward(states[s], a, t) for (s, a), t in pool.items()),
            "inward_pool_all_positions": sum(inward(states[s], a, t, strict=False) for (s, a), t in pool.items()),
            "legal_unfinished_pool_distance_2_or_3": sum(t == UNFINISHED and distance(states[s]) in (2, 3)
                                                        for (s, _), t in pool.items()),
            "current_train_view_supervised_overlap": {
                n: sum(r["in_same_split_supervised_V"] for r in read_jsonl(stage / n)) for n in sorted(train_views)},
            "leakage": leakage_report(new, read_jsonl(stage / "dev.jsonl"),
                                      {s: read_jsonl(stage / f"{s}.jsonl") for s in ("test_id", "test_ood")}, states),
        }
        tokenization = token_check(stage, args.tokenizer, states)
        require(all(r["max_input_tokens"] <= 128 and r["max_target_tokens"] <= 8
                    for r in tokenization["files"].values()), "Token limit exceeded")
        report["tokenization"] = tokenization
        write_object(stage / "audit.json", report)
        write_object(stage / "shortcut_audit.json", inspect_dataset(stage, True))
        updated = dict(manifest, data_revision="direction-controls-v1", previous_manifest_sha256=PARENT,
                       sha256={p.relative_to(stage).as_posix(): file_hash(p)
                               for p in sorted(stage.rglob("*")) if p.is_file()})
        write_object(stage / "manifest.json", updated)
        stage.rename(output)
    return report["direction_controls"]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parent", type=Path, default=Path("data/step_g_paired_actions"))
    parser.add_argument("--balanced", type=Path, default=Path("data/step_g_balanced"))
    parser.add_argument("--previous", type=Path, default=Path("data/step_last_move"))
    parser.add_argument("--source", type=Path, default=Path("data/derived"))
    for name in ("executor", "tokenizer", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    print(json.dumps(build(parser.parse_args()), indent=2))
