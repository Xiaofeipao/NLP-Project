"""Mine first V errors from fixed-G trajectories on training layouts."""
import argparse
from collections import Counter, defaultdict
import gc
import json
from pathlib import Path
import random

from ppnl.core import ACTIONS, OfficialOracle
from ppnl.data import read_jsonl, write_json, write_jsonl
from ppnl.experiment_freeze import file_hash
from ppnl.modeling import require_cuda
from ppnl.policy import greedy_plans
from state_baselines.run import CONFIG
from . import g_probes, last_move
from .audit import require
from .feedback_evaluation import SharedPolicy
from .path_validation import load_runner
from .schema import State
from .train_gpu import split


def mine(args):
    manifest = json.loads((args.data / "manifest.json").read_bytes())
    oracle = OfficialOracle(args.executor)
    state_path = args.data / "states.jsonl"
    require(oracle.sha256 == manifest["executor_sha256"] and file_hash(state_path) == manifest["sha256"]["states.jsonl"],
            "Changed oracle or state records")
    states = {r["id"]: State.from_record(r) for r in read_jsonl(state_path)}
    train = split(args.data, "train")
    supervised = {(r["state_id"], r["candidate"]) for r in train if r["mode"] == "v_step"}
    layouts = defaultdict(list)
    for r in train:
        if r["mode"] == "g_next":
            layouts[states[r["state_id"]].record()["layout_id"]].append(r)
    rng = random.Random(42)
    picked = sorted(rng.sample(sorted(layouts), args.layouts))
    samples = [rng.choice(sorted(layouts[k], key=lambda r: r["id"])) for k in picked]
    grids = [states[r["state_id"]].grid() for r in samples]

    torch = require_cuda()
    torch.set_num_threads(2)
    precision = "bfloat16" if torch.cuda.is_bf16_supported() else "float32"
    g = load_runner(args.generator, False, precision)
    policy = SharedPolicy(g_probes.generation_policy(g))
    plans = greedy_plans(grids, policy, masked=False, max_steps=CONFIG["max_steps"])
    del g, policy
    gc.collect()
    torch.cuda.empty_cache()
    v = load_runner(args.verifier, False, precision)

    traces, truth = [], {}
    for grid, plan in zip(grids, plans, strict=True):
        trace = []
        verdict = oracle.check(grid, plan)
        for i, (state, move) in enumerate(last_move.path_steps(grid, plan), 1):
            key = state, move
            if key not in truth:
                truth[key] = g_probes.reference(state, move, oracle)
            trace.append(key)
            if not verdict.feasible and i == verdict.step:
                break
        traces.append(trace)
    observations = list(truth)
    predicted = dict(zip(observations, g_probes.verify_moves(v, observations), strict=True))

    cases, groups = [], []
    for row, g, plan, trace in zip(samples, grids, plans, traces, strict=True):
        first = next(((i, key) for i, key in enumerate(trace, 1) if predicted[key] != truth[key]), None)
        case = {"train_g_id": row["id"], "layout_id": g.layout_id, "generated": plan,
                "path_truth": oracle.check(g, plan).label(), "checked_steps": len(trace), "first_mismatch": None}
        case["checks"] = [dict(step=i, state_id=s.id, action=a, target=truth[s, a], prediction=predicted[s, a])
                          for i, (s, a) in enumerate(trace, 1)]
        if first is not None:
            step, (s, move) = first
            group = []
            for action in ACTIONS:
                key = s, action
                label = truth[key] if key in truth else g_probes.reference(s, action, oracle)
                group.append(dict(action=action, target=label, input=g_probes.step_input(s, action),
                                  in_supervised_train=(s.id, action) in supervised))
            case["first_mismatch"] = {"step": step, "action": move, "actual": truth[s, move],
                                      "prediction": predicted[s, move], "state_id": s.id}
            groups.append(dict(train_g_id=row["id"], layout_id=g.layout_id, state=s.record(),
                               first_mismatch=case["first_mismatch"], alternatives=group))
        cases.append(case)
    require(len({g["layout_id"] for g in groups}) == len(groups), "Duplicate training layout")
    out = args.out
    out.mkdir(parents=True, exist_ok=False)
    write_jsonl(out / "train_rollouts.jsonl", cases)
    write_jsonl(out / "first_mismatch_groups.jsonl", groups)
    labels = Counter(r["target"] for g in groups for r in g["alternatives"])
    stats = dict(data_manifest_sha256=file_hash(args.data / "manifest.json"), seed=42, layouts=len(samples),
                 generator_sha256=file_hash(args.generator / "model.safetensors"),
                 verifier_sha256=file_hash(args.verifier / "model.safetensors"),
                 generator=str(args.generator), verifier=str(args.verifier), observed_state_actions=len(truth),
                 paths_with_first_mismatch=len(groups), alternative_label_counts=labels,
                 absent_from_supervised_train=sum(not r["in_supervised_train"]
                                                  for g in groups for r in g["alternatives"]),
                 first_truth=Counter(g["first_mismatch"]["actual"] for g in groups),
                 first_predictions=Counter(g["first_mismatch"]["prediction"] for g in groups))
    write_json(out / "summary.json", stats)
    print(json.dumps(stats, indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("data", "executor", "generator", "verifier", "out"):
        parser.add_argument("--" + name, required=True, type=Path)
    parser.add_argument("--layouts", type=int, default=256)
    mine(parser.parse_args())
