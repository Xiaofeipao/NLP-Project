"""Apply the five-token decision rule to a checkpoint trained with text loss."""
from ppnl.modeling import Seq2Seq
from . import g_probes
from .first_token import FirstTokenRunner
from .single import LABELS


class FirstTokenReadoutRunner(FirstTokenRunner):
    def load_model(self, checkpoint, **kwargs):
        model = Seq2Seq.load_model(self, checkpoint, **kwargs)
        if model.config.model_type != "t5" or getattr(model.config, "ppnl_verifier_loss", None) != g_probes.VERIFIER_LOSS:
            raise ValueError("The restricted readout control requires a T5 text-loss checkpoint")
        targets = self.tokenizer(text_target=list(LABELS), add_special_tokens=False)["input_ids"]
        self.verdict_ids = [t[0] for t in targets if t]
        if len(set(self.verdict_ids)) != len(LABELS) or set(self.verdict_ids) & set(self.tokenizer.all_special_ids):
            raise ValueError("The five verifier labels must start with distinct non-special tokens")
        return model

    def prepare_training(self, dataset):
        raise ValueError("The restricted readout control only runs inference")
