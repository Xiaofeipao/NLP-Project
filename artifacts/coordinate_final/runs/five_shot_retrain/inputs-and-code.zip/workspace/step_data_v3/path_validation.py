"""Score checkpoints on frozen complete paths and matched four-direction cases."""
import argparse
from collections import Counter, defaultdict
import gc
import json
from pathlib import Path

from ppnl.core import Grid, OfficialOracle
from ppnl.data import read_jsonl, write_json, write_jsonl
from ppnl.experiment_freeze import file_hash
from ppnl.modeling import require_cuda
from state_baselines.run import CONFIG
from state_baselines.workflow import verifier_report
from . import g_probes
from .audit import require
from .build import SOURCE_SHA
from .direction_controls import distance, inward
from .schema import State
from .train_gpu import TextVerifierRunner


def fixed_development(path, oracle):
    require(file_hash(path) == SOURCE_SHA["dev.jsonl"], "Changed full-path development partition")
    rows = [r for r in read_jsonl(path) if r["task"] == "verification"]
    require(Counter(r["valid"] for r in rows) == {True: 50, False: 50}, "Expected 50/50 full-path cases")
    grids = [Grid.from_dict(r["grid"]) for r in rows]
    plans = [r["candidate"] for r in rows]
    require(all(oracle.check(g, p).label() == r["label"] for g, p, r in zip(grids, plans, rows, strict=True)),
            "Full-path labels differ from the executor")
    return rows, grids, plans


def summarize_paths(rows, predictions):
    report = verifier_report(rows, predictions)
    outcomes = Counter((r["valid"], p == "valid") for r, p in zip(rows, predictions, strict=True))
    report.update(exact=sum(r["label"] == p for r, p in zip(rows, predictions, strict=True)),
                  true_valid=outcomes[True, True], false_valid=outcomes[False, True],
                  valid_total=sum(r["valid"] for r in rows))
    return report


def score_paths(runner, rows, grids, plans, out, *, goal_check=False):
    predictions = g_probes.verify_plans(runner, grids, plans, goal_check=goal_check)
    write_jsonl(out, [dict(id=r["id"], target=r["label"], prediction=p)
                      for r, p in zip(rows, predictions, strict=True)])
    return summarize_paths(rows, predictions)


def score_directions(runner, probes, states, out, *, goal_check=False):
    obs = [(states[r["state_id"]], r["candidate"]) for r in probes]
    require(all(g_probes.step_input(*o) == r["input"] for o, r in zip(obs, probes, strict=True)),
            "Changed four-direction prompt")
    results = (g_probes.verify_moves(runner, obs, goal_check=True) if goal_check
               else g_probes.verify_moves(runner, obs))
    wrong, opportunities, covered = Counter(), Counter(), defaultdict(list)
    records = []
    for r, p, (state, action) in zip(probes, results, obs, strict=True):
        target = r["target"]
        group = "adjacent" if distance(state) == 1 else "nonadjacent"
        if target != "valid":
            opportunities[group] += 1
            wrong[group] += p == "valid"
        if inward(state, action, target):
            opportunities["strict_inward"] += 1
            wrong["strict_inward"] += p == "valid"
        covered[r["state_id"]].append((target, p))
        records.append(dict(id=r["id"], state_id=r["state_id"], candidate=action, target=target,
                            prediction=p, distance=distance(state)))
    arrives = [v for v in covered.values() if any(t == "valid" for t, _ in v)]
    write_jsonl(out, records)
    return {"cases": len(probes), "correct": sum(r["target"] == p for r, p in zip(probes, results, strict=True)),
            "false_valid": dict(wrong), "false_valid_opportunities": dict(opportunities),
            "only_arriving_direction_called_valid": [
                sum(all((t == "valid") == (p == "valid") for t, p in v) for v in arrives), len(arrives)]}


def load_runner(checkpoint, head, precision, *, first_token=False, restricted_readout=False):
    runner_type = TextVerifierRunner
    if head:
        from .five_class import FiveClassRunner
        runner_type = FiveClassRunner
    elif first_token:
        from .first_token import FirstTokenRunner
        runner_type = FirstTokenRunner
    elif restricted_readout:
        from .first_token_readout import FirstTokenReadoutRunner
        runner_type = FirstTokenReadoutRunner
    settings = dict(CONFIG["training"], precision=precision, eval_batch_size=16,
                    max_input_tokens=512, max_target_tokens=8)
    return runner_type(str(checkpoint), dict(CONFIG, training=settings, local_files_only=True))


def rank(row):
    m = row["paths"]
    return (m["macro_f1"], m["first_error_localization_accuracy"], m["joint_error_accuracy"], -row["epoch"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("data", "source-dev", "executor", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    for name in ("old-text", "old-head", "new-text", "first-token", "restricted-readout", "baseline-results"):
        parser.add_argument("--" + name, type=Path)
    args = parser.parse_args()
    specs = [(name, head, first_token, readout, root) for name, head, first_token, readout, root in (
        ("old_text", False, False, False, args.old_text), ("old_head", True, False, False, args.old_head),
        ("targeted_text", False, False, False, args.new_text), ("first_token", False, True, False, args.first_token),
        ("restricted_readout", False, False, True, args.restricted_readout),
    ) if root is not None]
    if not specs:
        parser.error("Supply at least one checkpoint root")
    o = args.out
    o.mkdir(parents=True, exist_ok=False)
    oracle = OfficialOracle(args.executor)
    fixed, grids, plans = fixed_development(args.source_dev, oracle)
    manifest = args.data / "manifest.json"
    m = json.loads(manifest.read_bytes())
    require(oracle.sha256 == m["executor_sha256"], "Unexpected official executor")
    probe_file = args.data / "diagnostics/g_dev_four.jsonl"
    for filename in ("states.jsonl", "diagnostics/g_dev_four.jsonl"):
        require(file_hash(args.data / filename) == m["sha256"][filename], filename)
    probes = read_jsonl(probe_file)
    states = {r["id"]: State.from_record(r) for r in read_jsonl(args.data / "states.jsonl")}
    torch = require_cuda()
    torch.set_num_threads(2)
    precision = "bfloat16" if torch.cuda.is_bf16_supported() else "float32"
    report = {"dev_paths_source_sha256": file_hash(args.source_dev), "direction_probe_sha256": file_hash(probe_file),
              "selection_fields": ["binary_macro_f1", "first_error_localization", "joint_error",
                                   "earlier_epoch"], "runs": {}}
    if args.baseline_results:
        prior = json.loads(args.baseline_results.read_bytes())
        for k in ("dev_paths_source_sha256", "direction_probe_sha256", "selection_fields"):
            require(prior[k] == report[k], f"Baseline uses a different {k}")
        report["runs"].update(prior["runs"])
        report["baseline_results_sha256"] = file_hash(args.baseline_results)
    report["data_manifest_sha256"] = file_hash(manifest)
    for name, head, first_token, readout, root in specs:
        history = []
        for epoch in range(1, 4):
            ck = root / f"checkpoint-epoch-{epoch}"
            runner = load_runner(ck, head, precision, first_token=first_token, restricted_readout=readout)
            filename = f"{name}_epoch_{epoch}"
            history.append({"epoch": epoch, "checkpoint": str(ck), "verifier_head": head, "first_token": first_token, "restricted_readout": readout,
                            "paths": score_paths(runner, fixed, grids, plans, o / (filename + "_paths.jsonl")),
                            "directions": score_directions(runner, probes, states, o / (filename + "_directions.jsonl"))})
            report["runs"][name] = {"history": history, "selected": max(history, key=rank)}
            write_json(o / "path_selection.json", report)
            del runner
            gc.collect()
            torch.cuda.empty_cache()
            print(f"{name} epoch {epoch}: binary F1 {history[-1]['paths']['macro_f1']:.4f}", flush=True)


if __name__ == "__main__":
    main()
