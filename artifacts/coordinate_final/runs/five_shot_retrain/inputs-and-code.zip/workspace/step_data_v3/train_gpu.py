"""Train and evaluate the balanced single-step G/V dataset on a CUDA device."""
import argparse
from collections import Counter
from functools import partial
import hashlib
from pathlib import Path
import json
import time

from ppnl.core import Grid
from ppnl.data import read_jsonl, write_json, write_jsonl
from ppnl.evaluation import plan_metrics
from ppnl.experiment_freeze import file_hash
from ppnl.modeling import Seq2Seq, gpu_budget, require_cuda
from ppnl.optimization import accumulated_batches
from ppnl.policy import NAMES, greedy_plans
from state_baselines.run import CONFIG
from state_baselines.workflow import verifier_report
from . import g_probes
from .model_io import check_checkpoint, read_split
from .schema import State
from .shortcut_audit import metrics
from .single import LABELS


class RecordedSampler:
    """Expose the actual row order produced by PyTorch's seeded random sampler."""

    def __init__(self, sampler):
        self.sampler = sampler
        self.order = []

    def __iter__(self):
        self.order = list(self.sampler)
        return iter(self.order)

    def __len__(self):
        return len(self.sampler)


def split(dataset, name):
    return read_split(dataset, name, version=g_probes.VERSION, fingerprint=g_probes.template_hash())


def training_allocation(rows, manifest):
    """Check both the historical equal split and the state-complete revision."""
    gs = [r for r in rows if r["mode"] == "g_next"]
    vs = [r for r in rows if r["mode"] == "v_step"]
    per_class, generation = 400, 2000
    if manifest.get("data_revision") == g_probes.ORIGINAL_CASES_REVISION:
        generation = len({r["state_id"] for r in gs})
        per_direction = (4000 - generation) // (len(LABELS) * len(NAMES))
        per_class = per_direction * len(NAMES)
        expected = dict(generation=generation, verification_per_class=per_class, physical_per_direction=per_direction)
        if per_direction < 1 or manifest.get("training_allocation") != expected:
            raise ValueError("State coverage and declared train allocation disagree")
    counts = Counter(r["target"] for r in vs)
    directions = {label: Counter(r["candidate"] for r in vs if r["target"] == label)
                  for label in LABELS if label != "invalid_action_token"}
    if (len(gs) != generation or len(rows) != generation + per_class * len(LABELS)
            or counts != dict.fromkeys(LABELS, per_class)
            or any(values != dict.fromkeys(NAMES, per_class // len(NAMES)) for values in directions.values())):
        raise ValueError("Unexpected frozen task, V class, or physical-direction quotas")
    return counts, directions, generation


class TextVerifierRunner(Seq2Seq):
    verifier_loss = g_probes.VERIFIER_LOSS

    def load_model(self, checkpoint, **kwargs):
        model = super().load_model(checkpoint, **kwargs)
        if getattr(model.config, "ppnl_verifier_loss", None) == g_probes.FIRST_TOKEN_LOSS:
            raise ValueError("Load this checkpoint using FirstTokenRunner")
        return model

    def prepare_training(self, dataset):
        return g_probes.prepare_training(self, dataset)

    def batch_loss(self, batch):
        return g_probes.batch_loss(self, batch)


def validate_inputs(dataset, pretrained, backbone="flan_t5_base"):
    manifest = json.loads((dataset / "manifest.json").read_bytes())
    revision = (pretrained / "upstream_revision.txt").read_text().strip()
    if revision != CONFIG["models"][backbone]["revision"]:
        raise ValueError("Unexpected pretrained revision")
    if backbone == "flan_t5_base" and file_hash(pretrained / "tokenizer.json") != manifest["tokenizer_sha256"]:
        raise ValueError("Unexpected pretrained tokenizer")
    config = json.loads((pretrained / "config.json").read_bytes())
    if config["model_type"] != ("bart" if backbone == "bart_base" else "t5"):
        raise ValueError("Unexpected pretrained architecture")
    for name, expected in manifest["sha256"].items():
        if file_hash(dataset / name) != expected:
            raise ValueError(f"Changed dataset file: {name}")
    states = {r["id"]: State.from_record(r) for r in read_jsonl(dataset / "states.jsonl")}
    environments = {name: {states[r["state_id"]].record()["layout_id"] for r in split(dataset, name)}
                    for name in ("train", "dev")}
    for name in ("test_id", "test_ood"):
        environments[name] = {r["layout_id"] for r in split(dataset, name)}
    for a, b in (("train", "dev"), ("train", "test_id"), ("train", "test_ood"),
                 ("dev", "test_id"), ("dev", "test_ood")):
        if not environments[a].isdisjoint(environments[b]):
            raise ValueError(f"Layout leakage between {a} and {b}")
    return states


def local_v(runner, rows, check, *, states=None):
    if states is None:
        predictions = [p.strip() for p in runner.predict([r["input"] for r in rows], check)]
    else:
        # Held-out local diagnostics carry their own state outside the train/dev registry.
        observations = [(State.from_record(r["state"]) if "state" in r else states[r["state_id"]], r["candidate"])
                        for r in rows]
        if any(r["state_id"] != obs[0].id or r["input"] != g_probes.step_input(*obs)
               for r, obs in zip(rows, observations, strict=True)):
            raise ValueError("Endpoint-checked V input differs from the frozen prompt")
        predictions = g_probes.verify_moves(runner, observations, check, goal_check=True)
    result = metrics([r["target"] for r in rows], predictions)
    result["malformed"] = sum(p not in LABELS for p in predictions)
    return result, [dict(id=r["id"], target=r["target"], prediction=p)
                    for r, p in zip(rows, predictions, strict=True)]


def assess_dev(runner, rows, states, check, *, verifier=None):
    gs = [r for r in rows if r["mode"] == "g_next"]
    vs = [r for r in rows if r["mode"] == "v_step"]
    grids = [states[r["state_id"]].grid() for r in gs]
    scorer = g_probes.generation_policy(runner, check)
    scores = scorer.scores([(g, g.start) for g in grids])
    correct = sum(NAMES[max(range(4), key=s.__getitem__)] in r["optimal_actions"]
                  for r, s in zip(gs, scores, strict=True))
    plans = greedy_plans(grids, scorer, masked=False, max_steps=CONFIG["max_steps"])
    verification, records = (verifier or local_v)(runner, vs, check)
    return {"G_one_step_correct": correct, "G_one_step_total": len(gs),
            "G_greedy": plan_metrics(grids, plans), "V": verification}, records


def assess_test(runner, dataset, name, out, check, *, verifier=None, goal_check=False):
    rows = split(dataset, name)
    grids = [Grid.from_dict(r["grid"]) for r in rows]
    predictions = g_probes.verify_plans(runner, grids, [r["candidate"] for r in rows], check, goal_check=goal_check)
    report = verifier_report(rows, predictions)
    report["exact"] = sum(r["label"] == p for r, p in zip(rows, predictions, strict=True))
    write_jsonl(out / f"{name}_paths.jsonl",
                [dict(id=r["id"], target=r["label"], prediction=p)
                 for r, p in zip(rows, predictions, strict=True)])
    verify = verifier or local_v
    local, local_records = verify(runner, read_jsonl(dataset / "diagnostics" / f"{name}_local.jsonl"), check)
    balanced, _ = verify(runner, g_probes.read_heldout_subset(dataset, name), check)
    write_jsonl(out / f"{name}_steps.jsonl", local_records)
    return {"full_paths": report, "local_steps": local, "balanced_local_steps": balanced}


def train(args, states, phase, microbatch, precision, check):
    torch = require_cuda()
    torch.set_num_threads(2)
    settings = dict(CONFIG["training"], precision=precision, eval_batch_size=16,
                    max_input_tokens=128, max_target_tokens=8)
    if args.learning_rate is not None:
        settings["learning_rate"] = args.learning_rate
    effective_batch = args.effective_batch
    runner_type = TextVerifierRunner
    if args.verifier_head:
        from .five_class import FiveClassRunner
        runner_type = FiveClassRunner
    elif args.first_token:
        from .first_token import FirstTokenRunner
        runner_type = FirstTokenRunner
    runner = runner_type(str(args.from_checkpoint or args.pretrained), dict(CONFIG, training=settings))
    if args.from_checkpoint:
        check_checkpoint(runner, g_probes.template_hash())
        if getattr(runner.model.config, "ppnl_verifier_loss", None) != runner.verifier_loss:
            raise ValueError("Continuation checkpoint uses a different V loss")
    runner.model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    manifest = json.loads((args.data / "manifest.json").read_bytes())
    goal_check = args.goal_check or (args.first_token and manifest.get("data_revision") == g_probes.ORIGINAL_CASES_REVISION)
    verifier = partial(local_v, states=states) if goal_check else local_v
    features = runner.prepare_training(args.data)
    dev = split(args.data, "dev")
    if phase == "pilot":
        rows = split(args.data, "train")
        by_task = [[i for i, r in enumerate(rows) if r["mode"] == mode][:16] for mode in ("g_next", "v_step")]
        features = [features[i] for indices in by_task for i in indices]
        dev = [r for mode in ("g_next", "v_step") for r in [r for r in dev if r["mode"] == mode][:12]]
    generator = torch.Generator().manual_seed(CONFIG["seed"])
    sampler = None
    if args.shuffled:
        sampler = RecordedSampler(torch.utils.data.RandomSampler(features, generator=generator))
    loader = torch.utils.data.DataLoader(features, batch_size=microbatch, shuffle=sampler is None, sampler=sampler,
                                        collate_fn=runner.collate, generator=generator, pin_memory=True)
    path_development = args.grouped or args.shuffled
    if path_development:
        from ppnl.core import OfficialOracle
        from .grouped_batches import grouped_order
        from .path_validation import fixed_development, score_directions, score_paths

        source = split(args.data, "train")
        class_counts, direction_counts, generation = training_allocation(source, manifest)
        oracle = OfficialOracle(args.executor)
        probe_file = args.data / "diagnostics/g_dev_four.jsonl"
        if (oracle.sha256 != manifest["executor_sha256"] or
                file_hash(probe_file) != manifest["sha256"]["diagnostics/g_dev_four.jsonl"]):
            raise ValueError("Unexpected executor or directions probe")
        fixed, grids, plans = fixed_development(args.source_dev, oracle)
        probes = read_jsonl(probe_file)
        indices = [next(i for i, r in enumerate(source) if len(r.get("optimal_actions", ())) > 1)]
        indices.extend(next(i for i, r in enumerate(source) if r["mode"] == "v_step" and r["target"] == label)
                       for label in LABELS)
        smoke = runner.collate([features[i] for i in indices])
        runner.model.eval()
        with torch.no_grad(), runner.autocast():
            smoke_loss = runner.batch_loss(smoke).float().item()
        if not torch.isfinite(torch.tensor(smoke_loss)):
            raise ValueError("Nonfinite mixed preflight loss")
        preflight = {"first_token_ids": dict(zip(LABELS, runner.verdict_ids, strict=True)),
                     "v_labels": dict(class_counts), "physical_directions": direction_counts,
                     "sampling": "row_shuffle" if args.shuffled else "grouped_state",
                     "first_tokens": runner.tokenizer.convert_ids_to_tokens(runner.verdict_ids),
                     "g_token_ids": dict(zip(NAMES, runner.action_ids, strict=True)),
                     "decoder_start": runner.model.config.decoder_start_token_id,
                     "v_bos": runner.verdict_bos, "mixed_loss": smoke_loss,
                     "input_max_tokens": max(len(feature["input_ids"]) for feature in features),
                     "tokenizer_sha256": file_hash(args.pretrained / "tokenizer.json")}
        write_json(args.out / "preflight.json", preflight)
        print(json.dumps(preflight), flush=True)
    optimizer = torch.optim.AdamW(runner.model.parameters(), lr=settings["learning_rate"],
                                  weight_decay=settings["weight_decay"], fused=True)
    torch.cuda.reset_peak_memory_stats()
    history, best, best_rank = [], None, None
    checkpoints = []
    updates = 0
    started = time.monotonic()
    start = args.completed_epochs if args.from_checkpoint else 0
    epochs = 1 if phase == "pilot" else args.epochs

    def evaluate(epoch, records_suffix, loss_mean):
        nonlocal best, best_rank
        runner.model.eval()
        runner.model.config.use_cache = True
        runner.model.generation_config.use_cache = True
        assessment, records = assess_dev(runner, dev, states, check, verifier=verifier)
        assessment.update(epoch=epoch, updates=updates, train_mean_loss=loss_mean)
        rank = (assessment["V"]["macro_f1"], assessment["G_greedy"]["success_rate"],
                assessment["G_one_step_correct"])
        if path_development:
            goal_options = {"goal_check": True} if goal_check else {}
            paths = score_paths(runner, fixed, grids, plans, args.out / f"paths_{records_suffix}.jsonl", **goal_options)
            directions = score_directions(runner, probes, states, args.out / f"directions_{records_suffix}.jsonl", **goal_options)
            if args.grouped:
                assessment.update(grouping=grouping, order_sha256=order_hash)
            else:
                if sorted(sampler.order) != list(range(len(features))):
                    raise RuntimeError("Random sampler must visit each training row once per epoch")
                assessment["order_sha256"] = hashlib.sha256(json.dumps(sampler.order).encode()).hexdigest()
            assessment.update(paths=paths, directions=directions, sampling=preflight["sampling"],
                              checkpoint=str(args.out.resolve() / f"checkpoint-epoch-{epoch}"),
                              first_token=True, verifier_head=False)
            rank = (paths["macro_f1"], paths["first_error_localization_accuracy"], paths["joint_error_accuracy"])
        history.append(assessment)
        write_json(args.out / f"{phase}_history.json", history)
        write_jsonl(args.out / f"{phase}_dev_epoch_{records_suffix}.jsonl", records)
        print(json.dumps(assessment), flush=True)
        # The frozen random-order control has checkpoints at complete epochs only.
        eligible = not args.shuffled or int(epoch) == epoch
        improved = eligible and (best_rank is None or rank > best_rank)
        if phase == "train" and (args.from_checkpoint or args.save_every_epoch or improved):
            checkpoint = args.out / f"checkpoint-epoch-{epoch}"
            runner.model.save_pretrained(checkpoint)
            runner.tokenizer.save_pretrained(checkpoint)
            checkpoints.append((epoch, checkpoint))
        if phase == "train" and improved:
            best_rank = rank
            best = checkpoint
            fields = ["binary_macro_f1", "first_error_localization", "joint_error"] if path_development else [
                "dev V macro F1", "dev G greedy success rate", "dev G one-step correct"]
            write_json(args.out / "selection.json", {"selected": best.name, "epoch": epoch, "rank": fields})

    for epoch in range(start + 1, start + epochs + 1):
        if args.grouped:
            order, grouping = grouped_order(source, effective_batch, CONFIG["seed"] + epoch - 1,
                                            generation=generation, verification_per_class=class_counts[LABELS[0]])
            order_hash = hashlib.sha256(json.dumps(order).encode()).hexdigest()
            loader = torch.utils.data.DataLoader(features, batch_size=microbatch, sampler=order,
                                                 collate_fn=runner.collate, pin_memory=True)
        if path_development:
            midpoint = ((len(features) // 2 + effective_batch - 1) // effective_batch) * effective_batch
        runner.model.train()
        runner.model.config.use_cache = False
        optimizer.zero_grad(set_to_none=True)
        loss_sum, seen = 0.0, 0
        for _, batch, scale, update in accumulated_batches(loader, effective_batch // microbatch, "examples"):
            check()
            with runner.autocast():
                loss = runner.batch_loss(batch)
            (loss * scale).backward()
            loss_sum += loss.detach().float().item() * len(batch["labels"])
            seen += len(batch["labels"])
            if update:
                norm = torch.nn.utils.clip_grad_norm_(runner.model.parameters(), 1.0, error_if_nonfinite=True)
                if updates == 0 and not norm.item() > 0:
                    raise ValueError("First optimizer update has no gradient")
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
                updates += 1
                if updates % 25 == 0 or phase == "pilot":
                    progress = {"phase": phase, "epoch": epoch, "updates": updates, "epoch_examples": seen,
                                "train_mean_loss": loss_sum / seen, "elapsed_seconds": time.monotonic() - started,
                                "peak_reserved_mib": round(torch.cuda.max_memory_reserved() / 2**20)}
                    write_json(args.out / "progress.json", progress)
                    print(json.dumps(progress), flush=True)
                if path_development and seen == midpoint:
                    half = epoch - 0.5
                    evaluate(half, str(half), loss_sum / seen)
                    runner.model.train()
                    runner.model.config.use_cache = False
        evaluate(epoch, str(epoch), loss_sum / seen)
    result = {"phase": phase, "microbatch": microbatch, "precision": precision, "updates": updates,
              "verifier_loss": runner.model.config.ppnl_verifier_loss,
              "gpu": torch.cuda.get_device_name(), "peak_reserved_mib": round(torch.cuda.max_memory_reserved() / 2**20),
              "seconds": time.monotonic() - started, "dev": history}
    result["experiment"] = {
        "train_examples_per_epoch": len(features), "effective_batch": effective_batch,
        "seed": CONFIG["seed"], "learning_rate": settings["learning_rate"],
        "weight_decay": settings["weight_decay"], "optimizer": "AdamW",
        "pretrained_revision": (args.pretrained / "upstream_revision.txt").read_text().strip(),
        "manifest_sha256": file_hash(args.data / "manifest.json"),
        "prompt_sha256": runner.model.config.ppnl_prompt_sha256, "goal_check": goal_check,
    }
    if args.verifier_head:
        result["experiment"].update(
            verifier_head=runner.model.config.ppnl_verifier_head,
            class_order=runner.model.config.ppnl_verifier_labels,
            trainable_head_parameters=sum(p.numel() for p in runner.model.verifier_head.parameters()),
        )
    if args.first_token:
        result["experiment"].update(verifier_class_order=runner.model.config.ppnl_verifier_labels,
                                    verifier_token_ids=runner.model.config.ppnl_verifier_token_ids)
    if path_development:
        result.update(checkpoint=best.name, backbone=args.backbone, preflight=preflight)
    elif best:
        del optimizer
        del runner._collator
        del runner.model
        torch.cuda.empty_cache()
        result["checkpoint"] = best.name
        if args.from_checkpoint:
            result["continuation"] = {"from_checkpoint": str(args.from_checkpoint.resolve()),
                                      "completed_epochs": start, "optimizer": "fresh AdamW",
                                      "shuffle_seed": CONFIG["seed"]}
        tests_by_epoch = {}
        for epoch, checkpoint in checkpoints if args.from_checkpoint else [(None, best)]:
            destination = args.out / f"test_epoch_{epoch}" if epoch is not None else args.out
            destination.mkdir(exist_ok=True)
            runner.model = runner.load_model(checkpoint, local_files_only=True).to(runner.device)
            runner.model.eval()
            if checkpoint == best:
                _, replay = verifier(runner, [r for r in dev if r["mode"] == "v_step"], check)
                selected_epoch = int(checkpoint.name.rsplit("-", 1)[1])
                if replay != read_jsonl(args.out / f"{phase}_dev_epoch_{selected_epoch}.jsonl"):
                    raise RuntimeError("Reloaded model changed selected development predictions")
                result["selected_dev_predictions_reproduced"] = len(replay)
            reports = {name: assess_test(runner, args.data, name, destination, check, verifier=verifier, goal_check=goal_check)
                       for name in ("test_id", "test_ood")}
            del runner.model
            torch.cuda.empty_cache()
            if checkpoint == best:
                result["test"] = reports
            if epoch is not None:
                tests_by_epoch[epoch] = reports
        if tests_by_epoch:
            result["tests_by_epoch"] = tests_by_epoch
    write_json(args.out / f"{phase}_result.json", result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--pretrained", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--microbatch", type=int, default=4, choices=(1, 2, 4))
    parser.add_argument("--effective-batch", type=int, default=CONFIG["effective_batch"])
    parser.add_argument("--learning-rate", type=float)
    parser.add_argument("--backbone", choices=("flan_t5_base", "bart_base"), default="flan_t5_base")
    sampling = parser.add_mutually_exclusive_group()
    sampling.add_argument("--grouped", action="store_true")
    sampling.add_argument("--shuffled", action="store_true",
                          help="Use the original random row sampler and rank complete epochs on frozen paths")
    parser.add_argument("--source-dev", type=Path)
    parser.add_argument("--executor", type=Path)
    parser.add_argument("--epochs", type=int, default=CONFIG["epochs"], help="Number of epochs to run now")
    verifier = parser.add_mutually_exclusive_group()
    verifier.add_argument("--verifier-head", action="store_true",
                        help="Fit the independent five-way V head. At most three epochs in total, without a pilot.")
    verifier.add_argument("--first-token", action="store_true",
                          help="Classify V using cross-entropy over five distinct first tokens")
    parser.add_argument("--goal-check", action="store_true",
                        help="Allow valid only on arrival during first-token evaluation (automatic for original-state cases)")
    parser.add_argument("--no-pilot", action="store_true", help="Use the specified microbatch without a pilot")
    parser.add_argument("--save-every-epoch", action="store_true", help="Retain all training checkpoints")
    parser.add_argument("--from-checkpoint", type=Path, help="Start from saved weights with a fresh optimizer")
    parser.add_argument("--completed-epochs", type=int, default=0)
    args = parser.parse_args()
    if args.goal_check and not args.first_token:
        parser.error("--goal-check requires the first-token verifier")
    if args.epochs < 1 or args.completed_epochs < 0 or bool(args.from_checkpoint) != bool(args.completed_epochs):
        parser.error("Use a positive epoch count and specify both --from-checkpoint and --completed-epochs for continuation")
    if args.verifier_head and args.completed_epochs + args.epochs > 3:
        parser.error("The five-class experiment is capped at three total epochs")
    if (args.grouped or args.shuffled) and (not args.first_token or not args.source_dev or not args.executor
                                           or args.from_checkpoint or args.epochs > 3):
        parser.error("Path development requires first-token loss, development data and executor, and 1-3 fresh epochs")
    if args.backbone == "bart_base" and not args.grouped:
        parser.error("BART requires the grouped first-token protocol")
    if args.effective_batch < args.microbatch or args.effective_batch % args.microbatch:
        parser.error("Effective batch must be a positive multiple of the microbatch")
    if args.learning_rate is not None and not 0 < args.learning_rate < float("inf"):
        parser.error("Learning rate must be positive and finite")
    args.out.mkdir(parents=True, exist_ok=False)
    states = validate_inputs(args.data, args.pretrained, args.backbone)
    torch = require_cuda()
    precision = "bfloat16" if torch.cuda.is_bf16_supported() else "float32"
    microbatch = args.microbatch
    with gpu_budget(args.out / "gpu_ledger.json", 20, "balanced-gv") as check:
        if args.from_checkpoint or args.verifier_head or args.first_token or args.no_pilot:
            train(args, states, "train", microbatch, precision, check)
            return
        while True:
            try:
                print(f"Pilot: microbatch={microbatch}, precision={precision}", flush=True)
                train(args, states, "pilot", microbatch, precision, check)
                break
            except torch.cuda.OutOfMemoryError:
                if microbatch == 1:
                    raise
            microbatch //= 2
            torch.cuda.empty_cache()
        train(args, states, "train", microbatch, precision, check)


if __name__ == "__main__":
    main()
