"""Freeze 4,000 shared states with one G set and four independent compass V labels each."""
import argparse
from collections import Counter, defaultdict
import heapq
import json
from pathlib import Path
import random
from shutil import copyfile
from tempfile import TemporaryDirectory

from ppnl.core import ACTIONS, Grid, OfficialOracle
from ppnl.data import read_jsonl
from ppnl.experiment_freeze import file_hash
from ppnl.policy_v3_data import distances_to_goal, optimal_moves
from . import g_probes, last_move
from .audit import check_g, require
from .build import SOURCE_SHA, write_lines, write_object
from .schema import State, render
from .shortcut_audit import features
from .single import LABELS

REVISION = "shared-4000-states-four-directions-v1"
PARENT = "bdd2f5b4e99366ef32cb6f2a06dab89c2485617e4b6f0008d38ed0300ff1f94b"
SIZE = 4000
SEED = 42
WORD = "invalid_action_token"


def load_states(parent):
    records = read_jsonl(parent / "states.jsonl")
    states = {r["id"]: State.from_record(r) for r in records}
    require(len(records) == len(states) and all(s.id == sid for sid, s in states.items()), "State registry IDs")
    return states


def collect_training_states(rows, states, paths):
    """Keep eligible parent states; extra positions must have a witnessed prefix of a frozen train path."""
    used, source, words, old_g = {}, {}, defaultdict(list), {}
    for r in rows:
        sid = r["state_id"]
        s = states[sid]
        if s.current == s.goal:
            continue
        used[sid] = s
        source.setdefault(sid, dict(source="parent_train", row_id=r["id"], donor_id=r["donor_id"]))
        if r["mode"] == "g_next":
            old_g[sid] = r
        elif r["target"] == WORD:
            words[sid].append(r)
    maps = {(s.record()["layout_id"], s.goal) for s in used.values()}
    pool, witness = {}, {}
    for row in paths:
        grid = Grid.from_dict(row["grid"])
        if (grid.layout_id, grid.goal) not in maps:
            continue
        for field in (("target",) if row["task"] == "generation" else ("target_plan", "candidate")):
            for offset, (s, action) in enumerate(last_move.path_steps(grid, row[field])):
                if s.current != s.goal and s.id not in used:
                    if s.id not in pool:
                        pool[s.id] = s
                        witness[s.id] = dict(source="original_train_path", row_id=row["id"],
                                             path_field=field, completed_prefix_length=offset)
                if last_move.transition(s, action)[0] is None:
                    break
    return used, source, words, old_g, pool, witness


def compass_signature(state):
    return tuple(last_move.transition(state, a)[1] for a in ACTIONS)


def select_states(used, pool):
    """Stratify existing states by their observed four outcomes; no hand-authored map or case."""
    rng = random.Random(SEED)
    frequency = Counter(compass_signature(s) for s in used.values())
    bins = defaultdict(list)
    for sid in sorted(pool):
        bins[compass_signature(pool[sid])].append(sid)
    keys = sorted(bins)
    rng.shuffle(keys)
    queue = []
    for tie, pattern in enumerate(keys):
        rng.shuffle(bins[pattern])
        queue.append((frequency[pattern], tie, pattern))
    heapq.heapify(queue)
    chosen = []
    while len(used) + len(chosen) < SIZE:
        require(queue, "Insufficient distinct states in frozen trajectories")
        count, tie, pattern = heapq.heappop(queue)
        chosen.append(bins[pattern].pop())
        if bins[pattern]:
            heapq.heappush(queue, (count + 1, tie, pattern))
    return chosen


def views(case):
    """The state ID, provenance, other candidates and answers are never part of the model prompt."""
    yield case["generation"]
    yield from case["compass"]
    yield from case["lexical"]


def make_case(s, source, old_g, words, oracle):
    sid = s.id
    grid = s.grid()
    distances = distances_to_goal(grid)
    best = optimal_moves(grid, s.current, distances)
    target = old_g["target"] if old_g else best[0]
    g = dict(id=f"{sid}-G", state_id=sid, mode="g_next", task="generation", input=render("g_next", s),
             target=target, optimal_actions=best, distance=distances[s.current])
    check_g(g, s, oracle)
    if old_g:
        require(g["input"] == old_g["input"] and g["optimal_actions"] == old_g["optimal_actions"], sid)
    def verdict(a):
        row = dict(g_probes.example(s, a), id=f"{sid}-V-{a}", mode="v_step", task="verification")
        require(row["target"] == g_probes.reference(s, a, oracle), row["id"])
        return row
    physical = [verdict(a) for a in ACTIONS]
    lexical = []
    for old in words:
        row = verdict(old["candidate"])
        require(row["target"] == old["target"] == WORD and row["input"] == old["input"], old["id"])
        lexical.append(dict(row, original_v_id=old["id"]))
    return dict(id=sid, state_id=sid, layout_id=grid.layout_id, source=source,
                generation=g, compass=physical, lexical=lexical)


def audit_training(cases, states, tokenizer_file):
    from tokenizers import Tokenizer
    tokenizer = Tokenizer.from_file(str(tokenizer_file))
    n = len(cases)
    require(n == SIZE == len({c["state_id"] for c in cases}), "Expected distinct nonterminal states")
    outputs = [v for c in cases for v in views(c)]
    require(len(outputs) == len({v["input"] for v in outputs}) == len({v["id"] for v in outputs}), "Duplicate model input")
    g_ties, v_counts, directions, words = Counter(), Counter(), defaultdict(Counter), Counter()
    skeletons, physical_pairs, signatures = set(), Counter(), Counter()
    for c in cases:
        sid = c["state_id"]
        s = states[sid]
        require(s.current != s.goal and s.id == sid and [r["candidate"] for r in c["compass"]] == list(ACTIONS), sid)
        g = c["generation"]
        require(g["input"] == render("g_next", s) and bool(g["optimal_actions"]), g["id"])
        g_ties[len(g["optimal_actions"])] += 1
        sig = tuple(r["target"] for r in c["compass"])
        signatures[sig] += 1
        for a in sorted(set(sig)):
            for b in sorted(set(sig)):
                if a < b:
                    physical_pairs[f"{a}+{b}"] += 1
        for r in c["compass"] + c["lexical"]:
            a, label = r["candidate"], r["target"]
            require(r["input"] == g_probes.step_input(s, a) and r["state_id"] == sid, r["id"])
            v_counts[label] += 1
            skeletons.add(features(r, s)["constant_template"])
            if a in ACTIONS:
                directions[label][a] += 1
            else:
                require(label == WORD, r["id"])
                words[a] += 1
    require(set(v_counts) == set(LABELS) and len(skeletons) == 1, "V labels or template")
    require(all(set(v) == set(ACTIONS) for v in directions.values()), "Missing direction within physical class")
    require(all(sum(counts[a] for counts in directions.values()) == n for a in ACTIONS), "Action count")
    first_ids = {label: tokenizer.encode(label, add_special_tokens=False).ids[0] for label in LABELS}
    require(len(set(first_ids.values())) == len(LABELS), "Ambiguous V first tokens")
    unk = tokenizer.token_to_id("<unk>")
    input_max, target_max = 0, 0
    for i in range(0, len(outputs), 256):
        batch = outputs[i:i+256]
        inputs = tokenizer.encode_batch([r["input"] for r in batch])
        targets = tokenizer.encode_batch([r["target"] for r in batch])
        require(all(unk not in x.ids for x in inputs + targets), "Unknown token")
        require(tokenizer.decode_batch([x.ids for x in targets]) == [r["target"] for r in batch], "Target roundtrip")
        input_max = max(input_max, *(len(x.ids) for x in inputs))
        target_max = max(target_max, *(len(x.ids) for x in targets))
    require(input_max <= 128 and target_max <= 8, "Truncation would be required")
    return dict(state_cases=n, generation=n, g_optimal_count=g_ties, compass_verification=n*len(ACTIONS),
                lexical_verification=sum(words.values()), all_V=sum(v_counts.values()), all_task_views=len(outputs),
                v_label_counts=v_counts, direction_by_label=directions, lexical_by_word=words,
                direction_counts={a:n for a in ACTIONS}, observed_ordered_patterns=len(signatures),
                same_state_label_pairs=physical_pairs, v_prompt_structures=len(skeletons),
                verifier_first_tokens=first_ids, max_input_tokens=input_max, max_target_tokens=target_max)


def build(parent, source, output, executor, tokenizer):
    require(not output.exists(), "Choose a new output directory")
    manifest = json.loads((parent / "manifest.json").read_bytes())
    require(file_hash(parent / "manifest.json") == PARENT and file_hash(source) == SOURCE_SHA["train.jsonl"],
            "Unexpected parent or raw training partition")
    require(all(file_hash(parent / n) == h for n, h in manifest["sha256"].items()), "Modified parent")
    oracle = OfficialOracle(executor)
    require((oracle.sha256, file_hash(tokenizer)) == (manifest["executor_sha256"], manifest["tokenizer_sha256"]),
            "Executor/tokenizer version")
    registry = load_states(parent)
    rows, raw = read_jsonl(parent / "train.jsonl"), read_jsonl(source)
    used, provenance, words, old_g, pool, witness = collect_training_states(rows, registry, raw)
    baseline_n = len(used)
    added = select_states(used, pool)
    used.update((sid, pool[sid]) for sid in added)
    provenance.update((sid, witness[sid]) for sid in added)
    ids = sorted(used)
    random.Random(SEED).shuffle(ids)
    cases = [make_case(used[s], provenance[s], old_g.get(s), words[s], oracle) for s in ids]
    stats = audit_training(cases, used, tokenizer)
    train_layouts = {case["layout_id"] for case in cases}
    dev_layouts = {registry[r["state_id"]].record()["layout_id"] for r in read_jsonl(parent / "dev.jsonl")}
    tests = {n: {r["layout_id"] for r in read_jsonl(parent / (n + ".jsonl"))} for n in ("test_id", "test_ood")}
    overlap = {k: len(train_layouts & lays) for k, lays in {"dev":dev_layouts, **tests}.items()}
    require(not any(overlap.values()), "Split layout overlap")
    stats.update(from_original_formal_states=baseline_n, from_logged_train_paths=len(added),
                 additional_logged_state_pool=len(pool), layouts=len(train_layouts), layout_overlap=overlap)
    output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=output.parent) as tmp:
        stage = Path(tmp) / "dataset"
        (stage / "diagnostics").mkdir(parents=True)
        for name in ("dev.jsonl", "diagnostics/g_dev_four.jsonl"):
            copyfile(parent / name, stage / name)
        # Keep dev diagnostic states resolvable without including test references in training.
        registry.update(used)
        write_lines(stage / "states.jsonl", (registry[s].record() for s in sorted(registry)))
        write_lines(stage / "train.jsonl", cases)
        write_object(stage / "audit.json", stats)
        hashes = {p.relative_to(stage).as_posix(): file_hash(p) for p in sorted(stage.rglob("*")) if p.is_file()}
        write_object(stage / "manifest.json", dict(data_revision=REVISION, schema=g_probes.VERSION,
                    template_sha256=g_probes.template_hash(), tokenizer_sha256=manifest["tokenizer_sha256"],
                    executor_sha256=oracle.sha256, source_train_sha256=SOURCE_SHA["train.jsonl"],
                    parent_manifest_sha256=PARENT, seed=SEED, state_cases=SIZE, sha256=hashes))
        stage.rename(output)
    return stats


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("parent", "source", "out", "executor", "tokenizer"):
        parser.add_argument("--"+name, type=Path, required=True)
    a = parser.parse_args()
    print(json.dumps(build(a.parent, a.source, a.out, a.executor, a.tokenizer), indent=2))
