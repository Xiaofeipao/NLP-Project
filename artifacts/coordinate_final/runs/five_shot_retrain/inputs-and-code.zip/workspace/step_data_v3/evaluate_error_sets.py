"""Evaluate frozen models on the randomized single- and double-error branch."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path

from ppnl.core import Grid, OfficialOracle, execute, parse_verdict
from ppnl.data import read_jsonl
from ppnl.experiment_freeze import file_hash
from ppnl.policy import greedy_plans
from ppnl.policy_v3_data import distances_to_goal, optimal_moves
from . import g_probes, last_move
from .audit import require
from .build import write_lines, write_object
from .model_io import check_checkpoint
from .schema import State

COMMIT = "123bf5a1db4da2a676d4a83cf80974a888cd11db"
PARTITIONS = {
    "single": ("single_error_200.jsonl", "18020e883bb5eb0e91d2039393f741816b73b378ff245cb36d8a1449e02a347d", 1),
    "double": ("double_error_200.jsonl", "68340c517e9a4d3d20d74ba9bccd78b175bc06d2a2adad75330d5200237c563d", 2),
}


def audit(tests, dataset, executor):
    oracle = OfficialOracle(executor)
    registry = {r["id"]: r["layout_id"] for r in read_jsonl(dataset / "states.jsonl")}
    train = read_jsonl(dataset / "train.jsonl")
    excluded = {registry[r["state_id"]] for r in train + read_jsonl(dataset / "dev.jsonl")}
    seen_ids, seen_layouts = set(), set()
    parts, summaries = {}, {}
    for part, (filename, checksum, n_errors) in PARTITIONS.items():
        require(file_hash(tests / filename) == checksum, filename)
        rows = read_jsonl(tests / filename)
        require(len(rows) == 200, part)
        grids, plans = [], []
        for row in rows:
            grid, plan = Grid.from_dict(row["grid"]), row["candidate"]
            require(row["id"] not in seen_ids and grid.layout_id == row["layout_id"]
                    and grid.layout_id not in excluded | seen_layouts, row["id"])
            seen_ids.add(row["id"])
            seen_layouts.add(grid.layout_id)
            truth = oracle.check(grid, plan)
            require(not row["valid"] and not truth.valid and truth.label() == row["label"]
                    and (truth.step, truth.reason) == (row["step"], row["reason"])
                    and oracle.check(grid, row["reference_path"]).valid, row["id"])
            position, events = grid.start, []
            for step, a in enumerate(plan.split(), 1):
                dest, result = last_move.transition(State.from_grid(grid, position), a)
                if dest is None:
                    events.append((step, result))
                else:
                    position = dest
            if position != grid.goal:
                events.append((len(plan.split()) + 1, "goal_not_reached"))
            require(len(events) == row["edit_count"] == n_errors
                    and events == [(e["step"], e["reason"]) for e in row["audit_events"]]
                    and events[0] == (row["step"], row["reason"]), row["id"])
            if n_errors == 2:
                require(Counter(row["error_pair"]) == Counter(reason for _, reason in events), row["id"])
            grids.append(grid)
            plans.append(plan)
        parts[part] = rows, grids, plans
        summaries[part] = dict(rows=len(rows), valid_controls=0, first_reasons=Counter(r["reason"] for r in rows),
                               file_sha256=checksum, pairs=Counter("+".join(sorted(r["error_pair"])) for r in rows if "error_pair" in r))
    return parts, dict(commit=COMMIT, partitions=summaries, distinct_layouts=len(seen_layouts),
                       train_dev_layout_overlap=len(excluded & seen_layouts), executor_sha256=oracle.sha256)


def count_results(records):
    confusion = defaultdict(Counter)
    totals = Counter()
    for r in records:
        gold = parse_verdict(r["target"])
        parsed = parse_verdict(r["prediction"])
        require(parsed is not None and gold is not None and gold[0] is False, r["id"])
        valid, step, reason = parsed
        confusion[gold[2]][reason or "valid"] += 1
        totals["format_ok"] += 1
        totals["detected_invalid"] += not valid
        totals["first_type"] += reason == gold[2]
        totals["first_position"] += step == gold[1]
        totals["first_type_and_position"] += parsed == gold
    return dict(rows=len(records), **totals, confusion=confusion)


def evaluate(checkpoint, parts, out, *, source_dev=None, executor=None):
    from ppnl.modeling import require_cuda
    from state_baselines.run import CONFIG
    from .path_validation import load_runner
    torch = require_cuda()
    torch.set_num_threads(2)
    runner = load_runner(checkpoint, False, "bfloat16", first_token=True)
    check_checkpoint(runner, g_probes.template_hash())
    # Use identical inference inputs and batch order for both checkpoints, independent of labels.
    observations = {}
    for _, grids, plans in parts.values():
        for grid, plan in zip(grids, plans, strict=True):
            for s, a in last_move.path_steps(grid, plan):
                observations[s.id, a] = s, a
    keys = sorted(observations)
    prompts = [g_probes.step_input(*observations[k]) for k in keys]
    lengths = [len(ids) for ids in runner.tokenizer(prompts, truncation=False, verbose=False)["input_ids"]]
    training_limit = runner.input_limit
    runner.input_limit = max(training_limit, max(lengths))
    require(runner.input_limit <= 512, "Flan source context")
    labels = g_probes.verify_moves(runner, [observations[k] for k in keys], goal_check=True)
    cache = dict(zip(keys, labels, strict=True))
    report = {"checkpoint": str(checkpoint), "weights_sha256": file_hash(checkpoint / "model.safetensors"),
              "unique_verifier_inputs": len(keys), "goal_check": True, "precision": "bfloat16",
              "verdict_token_ids": runner.verdict_ids, "partitions": {}, "evaluator_sha256": file_hash(Path(__file__)),
              "input_lengths": dict(training_limit=training_limit, evaluation_limit=runner.input_limit,
                                    max_test_tokens=max(lengths), unique_inputs_above_training_limit=sum(n>training_limit for n in lengths),
                                    truncated=0)}
    if source_dev is not None:
        from .path_validation import fixed_development
        dev_rows, dev_grids, dev_plans = fixed_development(source_dev, OfficialOracle(executor))
        replay = g_probes.verify_plans(runner, dev_grids, dev_plans, goal_check=True)
        epoch = int(checkpoint.name.rsplit("-", 1)[1])
        candidates = (checkpoint.parent / f"dev_paths_epoch_{epoch}.jsonl", checkpoint.parent / f"paths_{epoch}.jsonl")
        prior = read_jsonl(next(p for p in candidates if p.is_file()))
        require([r["id"] for r in prior] == [r["id"] for r in dev_rows], "Development row IDs")
        require(replay == [r["prediction"] for r in prior], "Reloaded predictions differ on frozen development paths")
        report["development_predictions_replayed"] = len(replay)
    scorer = g_probes.generation_policy(runner)
    for part, (rows, grids, plans) in parts.items():
        predictions = last_move.scan(grids, plans, lambda obs: [cache[s.id, a] for s, a in obs])
        records = [dict(id=r["id"], target=r["label"], prediction=p) for r, p in zip(rows, predictions, strict=True)]
        write_lines(out / f"{part}_predictions.jsonl", records)
        report["partitions"][part] = count_results(records)
        # G receives the initial state only; the supplied erroneous plan is never its prompt.
        generated = greedy_plans(grids, scorer, masked=False, max_steps=CONFIG["max_steps"])
        g_rows = []
        for r, grid, plan in zip(rows, grids, generated, strict=True):
            best = optimal_moves(grid, grid.start, distances_to_goal(grid))
            tokens = plan.split()
            g_rows.append(dict(id=r["id"], plan=plan, optimal_actions=best,
                               first_move_correct=bool(tokens and tokens[0] in best), reaches_goal=execute(grid, plan).valid))
        write_lines(out / f"{part}_generation.jsonl", g_rows)
        report["partitions"][part]["G_shortest_first"] = sum(r["first_move_correct"] for r in g_rows)
        report["partitions"][part]["G_reaches_goal"] = sum(r["reaches_goal"] for r in g_rows)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("tests", "training-data", "executor", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--source-dev", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    parts, data_audit = audit(args.tests, args.training_data, args.executor)
    write_object(args.out / "test_audit.json", data_audit)
    if args.checkpoint:
        score = evaluate(args.checkpoint, parts, args.out, source_dev=args.source_dev, executor=args.executor)
        score["test_commit"] = COMMIT
        write_object(args.out / "scores.json", score)
        print(json.dumps(score, indent=2))
