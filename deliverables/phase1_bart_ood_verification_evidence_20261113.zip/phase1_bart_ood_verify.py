import json
from pathlib import Path
from types import SimpleNamespace
from zipfile import ZipFile, ZIP_DEFLATED

from ppnl.core import OfficialOracle
from ppnl.data import read_jsonl, write_json, write_jsonl
from ppnl.modeling import Seq2Seq, gpu_budget, require_cuda
from state_baselines.run import CONFIG, file_hash, grids_for, identity
from state_baselines.workflow import verifier_report, verify

root = Path("outputs")
data = Path("data/policy_v3")
executor = Path("vendor/executor-point-sg.py")
ledger = Path("E:/YanbingChen/NLP-Project-posttraining-20261112/outputs/gpu_ledger.json")
model = "bart_base"
checkpoint = root / "train" / model / "best"
selection_path = root / "selection.json"
selection = json.loads(selection_path.read_bytes())
if (selection["main_model"] != "flan_t5_base"
        or selection["identity"] != identity(SimpleNamespace(data=data, executor=executor))
        or selection["weights"][model] != file_hash(checkpoint / "model.safetensors")):
    raise ValueError("Frozen selection, data, source or weights do not match")

rows = read_jsonl(data / "test_ood.jsonl")
grids = grids_for(rows)
plans = [row["candidate"] for row in rows]
oracle = OfficialOracle(executor)
for row, grid in zip(rows, grids, strict=True):
    if oracle.check(grid, row["candidate"]).label() != row["label"]:
        raise ValueError(f"Unexpected gold label for {row['id']}")
require_cuda().set_num_threads(1)
with gpu_budget(ledger, 20, "phase1:test_ood:bart_base:verification") as check:
    runner = Seq2Seq(str(checkpoint), CONFIG)
    predictions = verify(runner, grids, plans, check)

out = root / "test_ood" / "bart_base_verification"
out.mkdir()
write_json(out / "metrics.json", verifier_report(rows, predictions))
write_jsonl(out / "predictions.jsonl", [
    dict(id=row["id"], candidate=row["candidate"], gold=row["label"], prediction=prediction)
    for row, prediction in zip(rows, predictions, strict=True)
])
with ZipFile(out / "evidence.zip", "x", ZIP_DEFLATED) as bundle:
    for path in (selection_path, out / "metrics.json", out / "predictions.jsonl"):
        bundle.write(path, path.name)
    bundle.write("phase1_bart_ood_verify.py")
print((out / "metrics.json").read_text(encoding="utf-8"))
