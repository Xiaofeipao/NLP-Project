import json
from collections import Counter
from pathlib import Path
from zipfile import ZipFile

from ppnl.core import Grid, OfficialOracle, parse_verdict
from ppnl.data import read_jsonl
from ppnl.evaluation import plan_metrics
from state_baselines.workflow import repair, verifier_report

root = Path(".cache/phase1_id")
dataset = read_jsonl("data/policy_v3/test_id.jsonl")
oracle = OfficialOracle(".cache/desktop_official_executor.py")
result = {}
with ZipFile("deliverables/phase1_development_evidence_20261113.zip") as evidence:
    assert (root / "selection.json").read_bytes() == evidence.read("outputs/selection.json")

for model in ("flan_t5_small", "flan_t5_base", "bart_base"):
    folder = root / "test_id" / model
    saved = json.loads((folder / "metrics.json").read_bytes())
    assert saved["model"] == model
    result[model] = {}
    for split, file in (("planning", "planning.jsonl"), ("fixed_candidates", "candidates.jsonl")):
        rows = read_jsonl(folder / file)
        grids = [Grid.from_dict(row["grid"]) for row in rows]
        assert [row["id"] for row in rows] == [row["id"] for row in dataset]
        assert [row["grid"] for row in rows] == [row["grid"] for row in dataset]
        if split == "fixed_candidates":
            assert [row["direct"] for row in rows] == [row["candidate"] for row in dataset]
        initial = [oracle.check(g, r["direct"]) for g, r in zip(grids, rows, strict=True)]
        assert [v.label() for v in initial] == [r["gold"] for r in rows]
        assert [v.reason for v in initial] == [r["reason"] for r in rows]
        metrics = saved[split]
        assert metrics["direct"] == plan_metrics(grids, [r["direct"] for r in rows])
        actual = [{"valid": v.valid, "step": v.step, "reason": v.reason} for v in initial]
        predictions = [r["self"]["feedback"] for r in rows]
        assert metrics["verification"] == verifier_report(actual, predictions)
        counts = Counter(v.reason or "valid" for v in initial)
        summary = {
            "initial_counts": dict(counts),
            "direct": metrics["direct"],
            "verification": {k: v for k, v in metrics["verification"].items() if k != "by_error"},
            "false_accepts": sum(not v.valid and parse_verdict(p) == (True, None, None)
                                 for v, p in zip(initial, predictions, strict=True)),
        }
        by_type = {reason: {"n": n, "self_repaired": 0, "executor_repaired": 0}
                   for reason, n in counts.items() if reason != "valid"}
        examples = {}
        for method in ("self", "executor"):
            finals = []
            for grid, row, truth in zip(grids, rows, initial, strict=True):
                branch = row[method]
                if method == "executor":
                    assert branch["feedback"] == truth.label()
                assert repair(grid, row["direct"], branch["feedback"]) == (branch["plan"], branch["status"])
                final = oracle.check(grid, branch["plan"])
                assert final.label() == branch["final_verdict"]
                finals.append(final)
                if not truth.valid and final.valid:
                    by_type[truth.reason][f"{method}_repaired"] += 1
                if not truth.valid and row["self"]["feedback"].strip() == "valid" and method == "executor" and final.valid:
                    examples.setdefault("rescued_after_self_accept", row)
                if not truth.valid and method == "self" and final.valid:
                    examples.setdefault("self_repaired", row)
            output = [r[method]["plan"] for r in rows]
            invalid = [i for i, v in enumerate(initial) if not v.valid]
            assert {k: metrics[method][k] for k in metrics["direct"]} == plan_metrics(grids, output)
            assert metrics[method]["invalid_candidate_repair"] == plan_metrics(
                [grids[i] for i in invalid], [output[i] for i in invalid])
            assert metrics[method]["outcomes"] == dict(Counter(r[method]["status"] for r in rows))
            summary[method] = {
                **metrics[method],
                "rescued": sum(not a.valid and b.valid for a, b in zip(initial, finals)),
                "regressions": sum(a.valid and not b.valid for a, b in zip(initial, finals)),
            }
        summary["repair_by_type"] = by_type
        summary["examples"] = examples
        result[model][split] = summary
Path(".cache/phase1_id_summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print("Verified 1,200 initial paths, 2,400 repair-branch outputs and all reported metrics.")
