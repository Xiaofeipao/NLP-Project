set -eu
cd /home/apulis-dev/code/NLP-Project-StepVerification-9eeb494
pid=$(cat /home/apulis-dev/outputs/NLP-Project-NewPart1-6939390/shortcut-study-20261119.pid)
while state=$(ps -p "$pid" -o stat=) && [ "${state#Z}" = "$state" ]; do sleep 5; done
test -s /home/apulis-dev/outputs/NLP-Project-NewPart1-6939390/shortcut-study-20261119/completed.json
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONUNBUFFERED=1
exec /home/apulis-dev/userdata/NLP-Project/venv/bin/python run_hierarchical_study.py --checkpoint /home/apulis-dev/outputs/NLP-Project-NewPart1-6939390/train/flan_t5_base/best --control /home/apulis-dev/outputs/NLP-Project-NewPart1-6939390/prompt-study-20261119-batched/adapter_github --previous /home/apulis-dev/outputs/NLP-Project-NewPart1-6939390/prompt-study-20261119-batched --out /home/apulis-dev/outputs/NLP-Project-NewPart1-6939390/shortcut-hierarchical-20261119 --evidence deliverables/step_verification_v1_v2_evidence.zip --executor vendor/ppnl/executor-point-sg.py --ledger /home/apulis-dev/outputs/NLP-Project-NewPart1-6939390/gpu_ledger.json
